package com.example.sun.test_ui_4.appUI;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class tripListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_list);
    }
}
